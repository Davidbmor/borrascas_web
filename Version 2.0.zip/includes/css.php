    <!-- CSS compartido -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= $assetBase ?? '' ?>assets/css/style.css">
    <link rel="stylesheet" href="<?= $assetBase ?? '' ?>assets/css/wizard.css">
